#!/bin/sh
#-----------------------------------------------------------------------------
# Date:2022-1-18
# work on CentOS(7.0及7.0以上)
# Minimum server configuration:4核8G 
#-----------------------------------------------------------------------------
#Source function library.
. /etc/init.d/functions

#设置颜色显示
SETCOLOR_SUCCESS="echo -en \\033[0;32m"
SETCOLOR_FAILURE="echo -en \\033[0;31m"
SETCOLOR_WARNING="echo -en \\033[1;33m"
SETCOLOR_NORMAL="echo -en \\033[0;39m"

#Set parameter
SERVER_HOME=/www/server
NGINX_HOME=/www/server/nginx
REDIS_HOME=/www/server/redis
MYSQL_HOME=/www/server/mysql
PHP_HOME=/www/server/php


#date
DATE=`date +"%y-%m-%d %H:%M:%S"`

#ip
IPADDR=`ip addr | grep -w inet | grep -v 127.0.0.1  | awk '{print $2}'`

#hostname
HOSTNAME=`hostname -s`

#user
USER=`whoami`

#disk_check
DISK_SDA=`df -h |grep -w "/" |awk '{print $5}'`

#cpu_average_check
cpu_uptime=`cat /proc/loadavg|awk '{print $1,$2,$3}'`

#脚本运行账号为root账户
ACCOUNT_JUDGE_FUN () {

	if [ "$(whoami)" != "root" ];then
			${SETCOLOR_WARNING} && echo "Warning：请使用root帐户安装系统!" && ${SETCOLOR_NORMAL}
			exit 1
	fi
}

#检查操作系统
CHECK_OS() {
    if [[ -f /etc/redhat-release ]]; then
        os="centos"
    elif cat /etc/issue | grep -Eqi "debian"; then
        os="debian"
    elif cat /etc/issue | grep -Eqi "ubuntu"; then
        os="ubuntu"
    elif cat /etc/issue | grep -Eqi "centos|red hat|redhat"; then
        os="centos"
    elif cat /proc/version | grep -Eqi "debian"; then
        os="debian"
    elif cat /proc/version | grep -Eqi "ubuntu"; then
        os="ubuntu"
    elif cat /proc/version | grep -Eqi "centos|red hat|redhat"; then
        os="centos"
    fi
}

MAIN() {
	CHECK_OS
	if [ ${os} != 'centos' ];then
		${SETCOLOR_WARNING} && echo "Warning：操作系统不是Centos!" && ${SETCOLOR_NORMAL}
		exit 1
	fi
}

#NGINX
NGINX() {

        echo "==========开始安装 NGINX==========="
        if [ -d ${NGINX_HOME} ];then
                ${SETCOLOR_WARNING} && echo "the folder ${NGINX_HOME} was already exist, please check it..." && ${SETCOLOR_NORMAL}
                exit 1
        else
			echo "创建nginx用户组和用户"
			nginxu=$(awk -F: '$0~/nginx/' /etc/passwd | wc -l)
			nginxg=$(awk -F: '$0~/nginx/' /etc/group | wc -l)
			#给nginx用户和组设置变量
			if [ $nginxu -ne 0 ] && [ $nginxg -ne 0 ]; then
				#判断nginx用户和组是否存在，不存在则创建
				${SETCOLOR_WARNING} && echo "nginx用户和组已存在" && ${SETCOLOR_NORMAL}
			else
				useradd -M -s /sbin/nologin nginx
			fi
			echo "安装依赖"
			yum -y install epel-release wget gcc automake autoconf libtool make gcc-c++  pcre-devel openssl-devel openssl-devel
			echo "下载并解压Nginx压缩包"
			wget https://qiniu.feelec.net/install/nginx-1.20.2.tar.gz
			tar -zxf nginx-1.20.2.tar.gz
			echo "编译并安装Nginx"
			cd nginx-1.20.2
			#源码编译nginx
			./configure --user=nginx --group=nginx --prefix=${SERVER_HOME}/nginx --conf-path=${SERVER_HOME}/nginx/conf/nginx.conf --with-http_stub_status_module --with-http_ssl_module
			make && make install
			echo "配置Nginx"
			#创建nginx的配置文件存放目录和证书存放目录
			mkdir -p /www/server/nginx/ssl
			mkdir -p /www/server/nginx/feelec
			cp /home/install/nginx-feelec.conf /www/server/nginx/feelec/
			#修改http配置文件,调度server配置文件存放目录
			echo "user  nginx nginx;
worker_processes  auto;
error_log  /www/server/nginx/logs/error.log;
pid        /www/server/nginx/logs/nginx.pid;
worker_rlimit_nofile 51200;

events {
    use epoll;
    worker_connections  51200;
}

http {
    include       mime.types;
    default_type  application/octet-stream;
    proxy_hide_header X-Powered-By;
    proxy_hide_header Server;
    server_tokens off;
    sendfile        on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout  65;
    client_max_body_size 100m;
    fastcgi_connect_timeout 300;
    fastcgi_send_timeout 300;
    fastcgi_read_timeout 300;
    fastcgi_buffer_size 64k;
    fastcgi_buffers 4 64k;
    fastcgi_busy_buffers_size 128k;
    fastcgi_temp_file_write_size 256k;
    fastcgi_intercept_errors on;
    gzip  on;
    gzip_http_version   1.1;
    gzip_min_length 1024;
    gzip_buffers 16 8k;
    gzip_comp_level 6;
    gzip_types text/plain application/x-javascript text/css application/xml image/jpeg image/gif image/png;
    include /www/server/nginx/feelec/*.conf;
}" > /www/server/nginx/conf/nginx.conf
			echo "[Unit]
Description=nginx
After=network.target

[Service]
Type=forking
ExecStart=/www/server/nginx/sbin/nginx
ExecReload=/www/server/nginx/sbin/nginx -s reload
ExecStop=/www/server/nginx/sbin/nginx -s quit
PrivateTmp=true

[Install]
WantedBy=multi-user.target
" > /lib/systemd/system/nginx.service
				systemctl daemon-reload
				systemctl enable nginx.service
				systemctl start nginx.service
                if [ $? -eq 0 ];then
                        ${SETCOLOR_SUCCESS} && echo " nginx service installation successfully!" && ${SETCOLOR_NORMAL}
                else
                        ${SETCOLOR_FAILURE} && echo "nginx fail to install,please check it!" && ${SETCOLOR_NORMAL}
                        exit 1
                fi
        fi
        echo "==========完成安装 NGINX==========="

}

#REDIS
REDIS() {

        echo "==========开始安装 REDIS==========="
        if [ -d ${REDIS_HOME} ];then
                ${SETCOLOR_WARNING} && echo "the folder ${REDIS_HOME} was already exist, please check it..." && ${SETCOLOR_NORMAL}
                exit 1
        else
			mkdir -p ${SERVER_HOME}/redis
			cd /home/install
			echo "安装依赖"
			yum -y install gcc centos-release-scl
			yum -y install devtoolset-9-gcc devtoolset-9-gcc-c++ devtoolset-9-binutils
			source /opt/rh/devtoolset-9/enable
			source /etc/profile
			echo "下载并解压Redis压缩包"
			wget https://qiniu.feelec.net/install/redis-6.0.4.tar.gz
			tar -zxf redis-6.0.4.tar.gz
			echo "编译并安装Redis"
			cd redis-6.0.4
			#编译安装redis并指定安装目录
			make && make install PREFIX=${SERVER_HOME}/redis
			echo "配置Redis"
			#创建redis日志,pid和log存放目录
			mkdir -p ${SERVER_HOME}/redis/data
			mkdir -p ${SERVER_HOME}/redis/log
			cp /home/install/redis7001.conf ${SERVER_HOME}/redis/
			echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
			echo "net.core.somaxconn = 1024" >> /etc/sysctl.conf
			sysctl -p
			echo never > /sys/kernel/mm/transparent_hugepage/enabled
			echo "[Unit]
Description=Redis
After=network.target

[Service]
Type=forking
ExecStart=/www/server/redis/bin/redis-server /www/server/redis/redis7001.conf
ExecReload=/www/server/redis/bin/redis-server -s reload
ExecStop=ExecStop=/www/server/redis/bin/redis-server -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
" > /lib/systemd/system/redis.service
			systemctl daemon-reload
			systemctl enable redis.service
			systemctl start redis.service
			if [ $? -eq 0 ];then
				${SETCOLOR_SUCCESS} && echo " redis service installation successfully!" && ${SETCOLOR_NORMAL}
			else
				${SETCOLOR_FAILURE} && echo " redis fail to install,please check it!" && ${SETCOLOR_NORMAL}
				exit 1
			fi
        fi
        echo "==========完成安装 REDIS==========="

}

#MYSQL
MYSQL() {

        echo "==========开始安装 MYSQL==========="
        if [ -d ${MYSQL_HOME} ];then
                ${SETCOLOR_WARNING} && echo "the folder ${MYSQL_HOME} was already exist, please check it..." && ${SETCOLOR_NORMAL}
                exit 1
        else
			cd /home/install
			#检查是否安装mysql和mariadb,有的话就卸载
			rpm -qa | grep mysql | xargs rpm -e --nodeps
			rpm -qa | grep mariadb | xargs rpm -e --nodeps
			#关闭SELINUX
			echo "关闭SELinux"
			setenforce 0
			#安装依赖包
			echo "安装依赖"
			yum -y install libaio perl net-tools numactl
			cd /home/install
			echo "下载并解压Mysql压缩包"
			#下载并解压tar包并进入
			wget https://qiniu.feelec.net/install/mysql-5.7.30-1.el7.x86_64.rpm-bundle.tar
			tar -xf mysql-5.7.30-1.el7.x86_64.rpm-bundle.tar
			echo "RPM安装Mysql"
			#安装rpm包
			rpm -ivh mysql-community-common-5.7.30-1.el7.x86_64.rpm
			rpm -ivh mysql-community-libs-5.7.30-1.el7.x86_64.rpm
			rpm -ivh mysql-community-client-5.7.30-1.el7.x86_64.rpm
			rpm -ivh mysql-community-server-5.7.30-1.el7.x86_64.rpm --force --nodeps
			echo "创建Mysql用户"
			useradd -M -s /sbin/nologin mysql
			echo "配置Mysql"
			#创建编译存储目录,并赋予权限
			mkdir -p ${SERVER_HOME}/mysql/data
			mkdir -p ${SERVER_HOME}/mysql/log/
			touch ${SERVER_HOME}/mysql/log/mysqld.log
			chown -R mysql:mysql ${SERVER_HOME}/mysql
			#创建mysql的配置文件,该配置为4核8G的调优配置
			echo '[client]
port		= 3306
socket		= /tmp/mysql.sock
default-character-set=utf8mb4
[mysqld]
log_timestamps=SYSTEM
interactive_timeout= 1800
wait_timeout = 1800
connect_timeout = 60
character-set-server=utf8mb4
log-error=/www/server/mysql/log/mysqld.log
sync_binlog=1
innodb_flush_log_at_trx_commit =1
binlog_cache_size = 192K
thread_stack = 384K
join_buffer_size = 4096K
query_cache_type = 1
max_heap_table_size = 1024M
port		= 3306
socket		= /tmp/mysql.sock
datadir = /www/server/mysql/data
default_storage_engine = InnoDB
performance_schema_max_table_instances = 400
table_definition_cache = 400
skip-external-locking
key_buffer_size = 384M
max_allowed_packet = 100G
table_open_cache = 1024
sort_buffer_size = 2048K
net_buffer_length = 4K
read_buffer_size = 2048K
read_rnd_buffer_size = 1024K
myisam_sort_buffer_size = 128M
thread_cache_size = 192
query_cache_size = 100M
tmp_table_size = 512M
sql-mode=NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES
explicit_defaults_for_timestamp = true
max_connections = 2000
max_connect_errors = 200
open_files_limit = 65535

log-bin=mysql-bin
binlog_format=mixed
server-id = 1
expire_logs_days = 10
slow_query_log=1
slow-query-log-file=/www/server/mysql/log/mysql-slow.log
long_query_time=3
early-plugin-load = ""


innodb_data_home_dir = /www/server/mysql/data
innodb_data_file_path = ibdata1:10M:autoextend
innodb_log_group_home_dir = /www/server/mysql/data
innodb_buffer_pool_size = 1024M
innodb_log_file_size = 1024M
innodb_log_buffer_size = 256M
innodb_flush_log_at_trx_commit = 2
innodb_lock_wait_timeout = 50
innodb_max_dirty_pages_pct = 90
innodb_read_io_threads = 16
innodb_write_io_threads = 16

[mysql]
no-auto-rehash

[myisamchk]
key_buffer_size = 256M
sort_buffer_size = 8M
read_buffer = 2M
write_buffer = 2M

[mysqlhotcopy]
interactive-timeout ' >/etc/my.cnf
			systemctl enable mysqld
			systemctl start mysqld
			systemctl status mysqld 
			if [ $? -eq 0 ];then
				${SETCOLOR_SUCCESS} && echo " mysql service installation successfully!" && ${SETCOLOR_NORMAL}
			${SETCOLOR_SUCCESS} &&	echo "安装目录:${SERVER_HOME}/mysql , 数据存放目录:${SERVER_HOME}/mysql/data , 配置文件:/etc/my.cnf , 错误日志和慢日志:${SERVER_HOME}/mysql/log , 端口: 3306 所做优化针对:4核8G" && ${SETCOLOR_NORMAL}
			else
				${SETCOLOR_FAILURE} && echo " mysql fail to install,please check it!" && ${SETCOLOR_NORMAL}
				exit 1
			fi
        fi
        echo "==========完成安装 MYSQL==========="

}

#PHP7.2
PHP() {

        echo "==========开始安装 PHP7.2==========="
        if [ -d ${PHP_HOME} ];then
                ${SETCOLOR_WARNING} && echo "the folder ${PHP_HOME} was already exist, please check it..." && ${SETCOLOR_NORMAL}
                exit 1
        else
			#安装依赖
			echo "安装依赖"
			yum -y install zip unzip gcc gcc-c++ make zlib zlib-devel pcre pcre-devel libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel libxml2 libxml2-devel glibc glibc-devel glib2 glib2-devel bzip2 bzip2-devel ncurses ncurses-devel curl curl-devel e2fsprogs e2fsprogs-devel krb5-devel openssl openssl-devel openldap openldap-devel nss_ldap openldap-clients openldap-servers libc-client libc-client-devel libxslt-devel autoconf libsodium
			#下载并解压PHP安装包安装
			cd /home/install
			echo "下载并解压PHP压缩包"
			wget https://qiniu.feelec.net/install/php-7.2.18.tar.gz
			tar zxf php-7.2.18.tar.gz
			cd php-7.2.18
			cp ./ext/phar/phar/phar.php ./ext/phar.phar  
			echo "/usr/local/lib" >/etc/ld.so.conf.d/local.conf  
			#安装ldap,curl和mcrypt支持库
			cd /home/install
			cp -frp /usr/lib64/libldap* /usr/lib
			cp /usr/lib64/libc-client.so.2007 /usr/lib64/libc-client.so
			ln -s /usr/lib64/libc-client.so /usr/lib/libc-client.so
			echo "下载并解压libmcrypt压缩包"
			#下载并解压libmcrypt
			wget https://qiniu.feelec.net/install/libmcrypt-2.5.8.tar.gz
			tar -zxf libmcrypt-2.5.8.tar.gz
			echo "安装libmcrypt"
			cd /home/install/libmcrypt-2.5.8
			./configure
			make && make install
			echo "安装PHP"
			#安装php	
			cd /home/install/php-7.2.18
			./configure --prefix=/www/server/php --with-config-file-path=/etc/php --enable-fpm --with-fpm-user=nginx --with-fpm-group=nginx --enable-mysqlnd --with-mysqli=mysqlnd --with-pdo-mysql=mysqlnd --enable-mysqlnd-compression-support --with-iconv-dir --with-freetype-dir --with-jpeg-dir --with-png-dir --with-zlib --with-libxml-dir --enable-xml --disable-rpath --enable-bcmath --enable-shmop --enable-sysvsem --enable-inline-optimization --with-curl --enable-mbregex --enable-mbstring --with-libmbfl --enable-ftp --with-gd --enable-gd-jis-conv --with-openssl --with-mhash --enable-pcntl --enable-sockets --with-xmlrpc --enable-zip --enable-soap --with-gettext --enable-fileinfo --enable-opcache --with-pear --enable-maintainer-zts --with-ldap=shared --without-gdbm --with-imap --with-imap-ssl --with-kerberos
			make && make install
			mkdir -p /etc/php
			cp /home/install/php.ini /etc/php/php.ini
			echo "PATH=/www/server/nginx/sbin:/www/server/php/bin:$PATH" >>/etc/profile
			source /etc/profile
			source /etc/profile
			#配置php-fpm
			cd /www/server/php/etc
			cp php-fpm.conf.default php-fpm.conf
			cp ./php-fpm.d/www.conf.default ./php-fpm.d/www.conf
			#将php-fpm添加为系统服务
			echo "
			[Unit]
Description=The PHP FastCGI Process Manager
After=syslog.target network.target

[Service]
Type=simple
PIDFile=/www/server/php/var/run/php-fpm.pid
ExecStart=/www/server/php/sbin/php-fpm --nodaemonize --fpm-config /www/server/php/etc/php-fpm.conf
ExecReload=/bin/kill -USR2 $MAINPID
ExecStop=/bin/kill -SIGINT $MAINPID

[Install]
WantedBy=multi-user.target
			" > /usr/lib/systemd/system/php-fpm.service
			systemctl daemon-reload
			systemctl start php-fpm
			systemctl enable php-fpm.service
			if [ $? -eq 0 ];then
				${SETCOLOR_SUCCESS} && echo " php7.2 service installation successfully!" && ${SETCOLOR_NORMAL}
			else
				${SETCOLOR_FAILURE} && echo " php7.2 fail to install,please check it!" && ${SETCOLOR_NORMAL}
				exit 1
			fi
        fi
        echo "==========完成安装 PHP7.2==========="

}

#PHP7.2扩展
PHP_EXTEND() {

        echo "=========开始安装PHP7.2扩展==========="
			echo "安装Redis扩展"
			cd /home/install
			echo "下载并解压Redis扩展包"
			wget https://qiniu.feelec.net/install/phpredis.zip
			unzip phpredis.zip
			echo "编译安装Redis扩展"
			cd phpredis
			${SERVER_HOME}/php/bin/phpize
			./configure --with-php-config=/www/server/php/bin/php-config
			make && make install
			echo "extension=redis.so" >>/etc/php/php.ini
			systemctl restart php-fpm
			if [ $? -eq 0 ];then
				${SETCOLOR_SUCCESS} && echo " php7.2 extend service installation successfully!" && ${SETCOLOR_NORMAL}
			else
				${SETCOLOR_FAILURE} && echo " php7.2 extend fail to install,please check it!" && ${SETCOLOR_NORMAL}
				exit 1
			fi
        echo "==========完成安装 PHP7.2扩展==========="

}


#开始安装
ACCOUNT_JUDGE_FUN
MAIN
#####################Feelec应用环境安装脚本-主菜单########################################
while true
do
clear
echo "====================================================="
echo "Feelec应用环境安装脚本"
echo "====================================================="
cat << EOF
|================System Infomation===================
| DATE       :$DATE
| HOSTNAME   :$HOSTNAME
| USER       :$USER
| IP         :$IPADDR
| DISK_USED  :$DISK_SDA
| CPU_AVERAGE:$cpu_uptime
| PATH		 :${SERVER_HOME}
=====================================================
|****Please Enter Your Choice:[1-8]****|
=====================================================

(1) Install All
(2) Install Not Mysql
(3) Install Not Nginx
(4) Install Redis
(5) Install Mysql
(6) Install PHP
(7) Install PHP Extend
(8) Quit
EOF
#choice
stty erase '^H'
read -p "Please enter your choice[1-8]: " input1

case "$input1" in
1)
	NGINX
	REDIS
	MYSQL
	PHP
	PHP_EXTEND
  ;;
2)
	NGINX
	REDIS
	PHP
	PHP_EXTEND
  ;;
3)
	REDIS
	MYSQL
	PHP
	PHP_EXTEND
	SUPERVISOR
  ;;
4)
	REDIS
  ;;
5)
	MYSQL
	;; 
6)
	PHP
	;; 
7)
	PHP_EXTEND
  ;;
8)
  clear
  break
  ;;
*)
  echo "----------------------------------"
  echo "|          Warning!!!            |"
  echo "|   Please Enter Right Choice!   |"
  echo "----------------------------------"
  for i in `seq -w 8 -1 1`
      do
        echo -ne "\b\b$i";
        sleep 1;
  done
  clear
esac
done
